// pages/user/student/function/lend/lend.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    name:null,
    number:null,
    howlong:null,
    reason:null,
    itemname:null,
    datetime:null,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var util = require('../../../../../utils/util.js');
    this.data.datetime = util.formatTime(new Date());
    this.setData({
      datetime: this.data.datetime
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  name_input: function (event) {
    this.setData({ name: event.detail.value })
  },

  number_input: function (event) {
    this.setData({ number: event.detail.value })
  },

  howlong_input: function (event) {
    this.setData({ howlong: event.detail.value })
  },

  reason_input: function (event) {
    this.setData({ reason: event.detail.value })
  },

  itemname_input: function (event) {
    this.setData({ item: event.detail.value })
  },


  confirm: function () {
    if (this.data.name == null || this.data.number == null || this.data.itemname == null || this.data.howlong == null || this.data.reason == null) {
      wx.showModal({
        content: '不允许输入为空，请重新输入',
        showCancel: false,
        success: function (res) {
          if (res.confirm) {
            console.log('用户点击确定')
          }
        }
      });
    } else {
      wx.showToast({
        title: '已完成',
        icon: 'success',
        duration: 3000
      });

      var that = this
      const db = wx.cloud.database()
      db.collection('lend').add({
      data: {
        name:that.data.name,
        number: that.data.number,
        howlong: that.data.howlong,
        reason: that.data.reason,
        datetime: that.data.datetime,
        itemname:that.data.item,
      },
      success: function (res) {
        // res 是一个对象，其中有 _id 字段标记刚创建的记录的 id
        console.log(res)
      }
    })

      wx.redirectTo({
        url: '../../../student/student',
      })

    }


  }
})