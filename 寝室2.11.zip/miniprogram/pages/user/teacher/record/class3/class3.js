// pages/user/teacher/record/record.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    grids: [
      {
        num:0,
        name: '学生1',
        show:true,
        icon: ''
      },
      {
        num: 1,
        name: '学生2',
        show: true,
        icon: ''
      },
      {
        num: 2,
        name: '学生3',
        show: false,
        icon: ''
      },
      {
        num: 3,
        name: '学生4',
        show: true,
        icon: ''
      },
      {
        num: 4,
        name: '学生5',
        show: true,
        icon: ''
      },
      {
        num: 5,
        name: '学生6',
        show: true,
        icon: ''
      },
      {
        num: 6,
        name: '学生7',
        show: false,
        icon: ''
      },
      {
        num: 7,
        name: '学生8',
        show: true,
        icon: ''
      },
      {
        num: 8,
        name: '学生10',
        show: true,
        icon: ''
      },
      {
        num: 9,
        name: '学生10',
        show: true,
        icon: ''
      },
      {
        num: 10,
        name: '学生11',
        show: true,
        icon: ''
      },
      {
        num: 11,
        name: '学生12',
        show: true,
        icon: ''
      },
      {
        num: 12,
        name: '学生13',
        show: true,
        icon: ''
      },
      {
        num: 13,
        name: '学生14',
        show: false,
        icon: ''
      },
      {
        num: 14,
        name: '学生15',
        show: true,
        icon: ''
      },
      {
        num: 15,
        name: '学生16',
        show: true,
        icon: ''
      },
      {
        num: 16,
        name: '学生17',
        show: true,
        icon: ''
      },
      {
        num: 17,
        name: '学生18',
        show: true,
        icon: ''
      },
      {
        num: 18,
        name: '学生19',
        show: true,
        icon: ''
      },
      {
        num: 19,
        name: '学生20',
        show: true,
        icon: ''
      },
      {
        num: 20,
        name: '学生21',
        show: false,
        icon: ''
      },
      {
        num: 21,
        name: '学生22',
        show: true,
        icon: ''
      },
      {
        num: 22,
        name: '学生23',
        show: true,
        icon: ''
      },
      {
        num: 23,
        name: '学生24',
        show: true,
        icon: ''
      },
      {
        num: 24,
        name: '学生25',
        show: false,
        icon: ''
      },
      {
        num: 25,
        name: '学生26',
        show: true,
        icon: ''
      },
      {
        num: 26,
        name: '学生27',
        show: true,
        icon: ''
      },
      {
        num: 27,
        name: '学生28',
        show: true,
        icon: ''
      },
      {
        num: 28,
        name: '学生29',
        show: true,
        icon: ''
      },
      {
        num: 29,
        name: '学生30',
        show: true,
        icon: ''
      },
      {
        num: 30,
        name: '学生31',
        show: true,
        icon: ''
      },
      {
        num: 31,
        name: '学生32',
        show: false,
        icon: ''
      },
      {
        num: 32,
        name: '学生33',
        show: true,
        icon: ''
      },
      {
        num: 33,
        name: '学生34',
        show: true,
        icon: ''
      },
      {
        num: 34,
        name: '学生35',
        show: true,
        icon: ''
      },
      {
        num: 35,
        name: '学生18',
        show: true,
        icon: ''
      },
      {
        num: 36,
        name: '学生20',
        show: true,
        icon: ''
      },
      {
        num: 37,
        name: '学生21',
        show: false,
        icon: ''
      },
      {
        num: 38,
        name: '学生22',
        show: true,
        icon: ''
      },
    ]
  },  

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  showorno: function(e){
    item.show;
     var isshow = this.data.show+num;
    // num = this.data.grids.num
    // var e = 'this.data.grids['+num+'].show'
    // this.setData({ [e]: !isshow})
    // var that = this;


  }
})