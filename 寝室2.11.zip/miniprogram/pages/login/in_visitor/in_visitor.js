// pages/login/login.js
var app = getApp();

Page({


  data: {
    focus: false,
    inputValue: '',
    idnumber:null,
    idname:null,
    purpose:null,
    datetime:null,
  },
  bindKeyInput: function (e) {
    this.setData({
      inputValue: e.detail.value
    })
  },
  bindReplaceInput: function (e) {
    var value = e.detail.value
    var pos = e.detail.cursor
    var left
    if (pos !== -1) {
      // 光标在中间
      left = e.detail.value.slice(0, pos)
      // 计算光标的位置
      pos = left.replace(/11/g, '2').length
    }

    // 直接返回对象，可以对输入进行过滤处理，同时可以控制光标的位置
    return {
      value: value.replace(/11/g, '2'),
      cursor: pos
    }

    // 或者直接返回字符串,光标在最后边
    // return value.replace(/11/g,'2'),
  },
  bindHideKeyboard: function (e) {
    if (e.detail.value === '123') {
      // 收起键盘
      wx.hideKeyboard()
    }
  },



  idnumber_input : function(event){
    this.setData({idnumber:event.detail.value})
  },

  idname_input : function(event){
    this.setData({idname:event.detail.value})
  },

  purpose_input: function (event) {
    this.setData({ purpose: event.detail.value })
  },

  btnclick : function(){
    if (this.data.idnumber == null || this.data.idname == null || this.data.purpose==null){
      wx.showModal({
        content: '不允许输入为空，请重新输入',
        showCancel: false,
        success: function (res) {
          if (res.confirm) {
            console.log('用户点击确定')
          }
        }
      });
    }else{


      var util = require('../../../utils/util.js');
      this.data.datetime = util.formatTime(new Date());
      this.setData({
        datetime: this.data.datetime
      })

      var that = this
      const db = wx.cloud.database()
      db.collection('visit').add({
        data: {
          idnumber: that.data.idnumber,
          idname: that.data.idname,
          purpose: that.data.purpose,
          datetime: that.data.datetime,
        },
        success: function (res) {
          // res 是一个对象，其中有 _id 字段标记刚创建的记录的 id
          console.log(res)
        }
      });
      wx.showToast({
        title: '已完成',
        icon: 'success',
        duration: 3000,
      });
      wx.redirectTo({
        url: '../../index/index',
      })
    }
  }
})
